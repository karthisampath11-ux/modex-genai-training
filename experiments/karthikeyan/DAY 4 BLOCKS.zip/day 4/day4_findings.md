# Day 4 Findings & Reflection

## Topics Learned

### 1. Reliability Patterns
Learned how production AI systems handle failures using retry logic and exponential backoff. Understood why naive retries are dangerous at scale and how backoff reduces API pressure.

### 2. In-Memory Caching
Implemented simple dictionary-based caching to avoid repeated Gemini API calls for identical inputs. Learned how caching improves speed, reduces latency, and lowers API costs.

### 3. Intro to RAG
Learned the high-level Retrieval Augmented Generation workflow:
chunk → embed → retrieve → augment prompt → generate.

Understood why LLMs require external retrieval systems for accurate domain-specific answers.

### 4. Self Code Review
Reviewed Day 3 utility like a senior engineer. Identified issues related to modularity, reliability, edge cases, and documentation quality.

### 5. Production-Oriented Improvements
Enhanced utility_v2.py with:
- retry logic
- exponential backoff
- in-memory caching
- better input validation

---

# Problems Faced

## Issue 1 — Cache Did Not Work Initially
The cache was resetting between separate Python executions because in-memory cache only survives during the same runtime session.

### Fix
Modified the script to demonstrate cache hits within the same execution flow.

---

## Issue 2 — Syntax/Indentation Errors
While replacing the main() function, indentation mistakes caused the script to fail silently.

### Fix
Replaced the broken section with a clean corrected version and re-tested execution.

---

# Key Engineering Learnings

- Reliability matters as much as functionality.
- Prompt chaining enables multi-step reasoning workflows.
- Caching reduces repeated API cost.
- Exponential backoff is important for production API stability.
- Documentation and README quality are important engineering skills.

---

# Artifacts Created Today

- utility_v2.py
- utility_v2_output.txt
- self_code_review.md
- README.md
- day4_findings.md

---

# Areas To Improve Further

- Persistent caching using Redis/database
- Better structured logging
- Async API processing
- Smarter retry handling
- More advanced RAG pipelines

---

# Overall Reflection

Day 4 focused heavily on production reliability and engineering maturity rather than only prompt engineering. The practicals improved understanding of scalable AI system design, caching workflows, retry mechanisms, and project organization practices.